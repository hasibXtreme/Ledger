    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="style.css">
        <title>Document</title>
    </head>
    <body>
        <?php  $n=(int)$_POST['entries']; ?>        
        
    <form action="project.php" method="post">
       <input type="hidden" name="entries" value="<?php echo $n; ?>">

        <?php for($i=0;$i<$n;$i++):?>
         
          <fieldset id="entry">
                  <h1>Entry number <?php echo $i+1?></h1>
                Cash: <input type="number" name="cash[]"><br>
                Accounts receivable: <input type="number" name="a_r[]"><br>
                Supply: <input type="number"name="supply[]"><br>
                Equipments: <input type="number" name="equipments[]"><br>
                Notes payable: <input type="number" name="notes_payable[]"><br>
                Accounts payable: <input type="number" name="a_p[]"><br>
                Capital: <input type="number" name="capital[]"><br>
                Owners equity: <input type="number" name="owners_equity[]"><br>
                Revenues: <input type="number" name="revenues[]"><br>
                Expenses: <input type="number" name="expenses[]"><br>
          </fieldset>
          <br>
        <?php endfor; ?>  

        <input type="submit" value="Submit">
    </form>    

    </body>
    </html>    
        
        
        
        
        
        
        